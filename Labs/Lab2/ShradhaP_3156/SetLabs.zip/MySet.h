#pragma once

#include <vector>
#include <iostream>

namespace std {

    class MySet {
    private:
        vector<int> items;

    public:
        MySet();

        void addItem(int item);
        void removeItem(int item);
        bool isItemOf(int item) const;
        bool isSubset(const MySet& other) const;
        int size() const;
        void printItems() const;
    };

} 