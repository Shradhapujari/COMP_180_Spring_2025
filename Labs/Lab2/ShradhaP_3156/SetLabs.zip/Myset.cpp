#include "MySet.h"
#include <vector>
#include <algorithm>

namespace std {

    MySet::MySet() {}

    void MySet::addItem(int item) {
        if (!isItemOf(item)) {
            items.push_back(item);
        }
    }

    void MySet::removeItem(int item) {
        auto it = find(items.begin(), items.end(), item);
        if (it != items.end()) {
            items.erase(it);
        }
    }

    bool MySet::isItemOf(int item) const {
        return find(items.begin(), items.end(), item) != items.end();
    }

    bool MySet::isSubset(const MySet& other) const {
        for (int item : items) {
            if (!other.isItemOf(item)) {
                return false;
            }
        }
        return true;
    }

    int MySet::size() const {
        return items.size();
    }

    void MySet::printItems() const {
        for (int item : items) {
            cout << item << " ";
        }
        cout << endl;
    }

}
