// Shradha Pujari
// Sets Lab 

#include <iostream>
#include "MySet.h"

using namespace std;

int main() {
    MySet set1, set2;
    int n, item;

    cout << "Enter number of items for Set1: ";
    cin >> n;
    cout << "Enter items for Set1: ";
    for (int i = 0; i < n; i++) {
        cin >> item;
        set1.addItem(item);
    }

    cout << "Enter number of items for Set2: ";
    cin >> n;
    cout << "Enter items for Set2: ";
    for (int i = 0; i < n; i++) {
        cin >> item;
        set2.addItem(item);
    }

    cout << "Set1 items: ";
    set1.printItems();

    cout << "Set2 items: ";
    set2.printItems();

    cout << "Set2 is subset of Set1: " << (set2.isSubset(set1) ? "Yes" : "No") << endl;
    cout << "Set1 is subset of Set2: " << (set1.isSubset(set2) ? "Yes" : "No") << endl;

   
    cout << "Enter item to remove from Set1: ";
    cin >> item;
    set1.removeItem(item);
    cout << "Set1 items after removing " << item << ": ";
    set1.printItems();

    return 0;
}
