#pragma once
#include "Location.h"
class Crystal :
    public Location
{
private:
    bool taken;
public:
    Crystal();
    int visit(Player& p);
    void draw();
};

