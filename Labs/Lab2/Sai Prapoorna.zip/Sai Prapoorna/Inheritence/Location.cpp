#include "Location.h"
Location::Location(char s) {
	sysmbol = s;
	visited = false;
}
int Location::visit(Player& p) {
	visited = true;
	return 1;
}
void Location::draw() {
	if (visited) cout << sysmbol;
	else cout << ".";
}