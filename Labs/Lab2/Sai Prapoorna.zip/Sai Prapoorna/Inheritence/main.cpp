#include <iostream>
#include "Location.h"
#include "Crystal.h"
#include "Player.h"
using namespace std;
int main() {
	Player p;
	Crystal crystal;
	Location loc;
	cout << "Drawing Intial States:" << endl;
	loc.draw();
	crystal.draw();
	cout << endl << "Visiting the location" << endl;
	loc.visit(p);
	crystal.visit(p);
	cout << endl << "Redrawing Location: " << endl;
	loc.draw();
	crystal.draw();
	return 0;

}

