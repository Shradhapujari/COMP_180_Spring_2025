#pragma once
#include <iostream>
#include <string>

using namespace std;

class Player {
private:
    string name;
    int age;
    int score;
    int x, y;

public:
    Player();
    Player(string, int, int);
    Player(int, int);

    void SetName(string);
    void SetAge(int);
    void SetScore(int);

    string GetName();
    int GetAge();
    int GetScore();

    void PrintInfo();
    void SetCoordinates(int, int);
};
