#include "location.h"
#include "player.h"

location::location(char s, int x, int y) : symbol(s), visited(false), x(x), y(y) {
}

void location::setSymbol(char s) {
    symbol = s;
}

char location::getSymbol() {
    return symbol;
}

bool location::isVisited() {
    return visited;
}

int location::getX() {
    return x;
}

int location::getY() {
    return y;
}

void location::draw() {
    if (visited) {
        cout << symbol;
    }
    else {
        cout << ".";
    }
}

int location::visit(Player& p) {
    visited = true;
    return 1;
}
