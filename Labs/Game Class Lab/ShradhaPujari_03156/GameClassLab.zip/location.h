#pragma once
#include <iostream>
#include "Player.h"

using namespace std;

class location {
protected:
    bool visited;
    char symbol;
    int x, y; 

public:
    location(char s = ' ', int x = 0, int y = 0);
    void setSymbol(char s);
    char getSymbol();
    bool isVisited();
    int getX();
    int getY();
    virtual void draw();
    virtual int visit(Player& p);
};
