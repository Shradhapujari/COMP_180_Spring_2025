// Shradha Pujari
// Game Class Lab

#include "Game.h"
#include <iostream>
#include <vector>

using namespace std;

Game::Game() : rows(0), cols(0), world(nullptr), thiefRow(0), thiefCol(0), guardRow(0), guardCol(0) {}

Game::~Game() {
    cleanUp();
}

void Game::cleanUp()
{
    if (world != nullptr)
    {
        for (int i = 0; i < rows; i++) 
        {
            for (int j = 0; j < cols; j++)
            {
                delete world[i][j];
            }
            delete[] world[i];
        }
        delete[] world;
        world = nullptr;
    }
}

void Game::setUpGame(int rows, int cols, int thiefStartRow, int thiefStartCol, int guardStartRow, int guardStartCol) 
{
    this->rows = rows;
    this->cols = cols;
    world = new location * *[rows];

    for (int i = 0; i < rows; i++)
    {
        world[i] = new location * [cols];
        for (int j = 0; j < cols; j++) 
        {
            world[i][j] = new location(' ');
        }
    }

    thiefRow = thiefStartRow;
    thiefCol = thiefStartCol;
    guardRow = guardStartRow;
    guardCol = guardStartCol;

    world[guardRow][guardCol] = new location('G'); 
}

void Game::drawGame()
{
    system("cls");
    for (int i = 0; i < rows; i++) 
    {
        for (int j = 0; j < cols; j++) 
        {
            if (i == thiefRow && j == thiefCol) 
            {
                cout << 'T';
            }
            else
            {
                world[i][j]->draw();
            }
        }
        cout << endl;
    }
}

void Game::playGame() {
    setUpGame(5, 5, 0, 0, 2, 2);
    char command;
    do 
    {
        drawGame();
        cout << "Enter the direction (w/a/s/d to move, q to quit): ";
        cin >> command;
        if (command == 'q') break;

        if (command != 'w' && command != 'a' && command != 's' && command != 'd')
        {
            cout << "Invalid command! Try again.\n";

            cout << "Do you want to continue? (y/n): ";

            cin >> command;

            if (command == 'n') 
                break;

            else continue;
        }

        moveThief(command);

        if (thiefRow == guardRow && thiefCol == guardCol) 
        {
            cout << "Thief is found! Game Over." << endl;
            break;
        }
    } while (true);
}

void Game::moveThief(char direction) 
{
    int newRow = thiefRow;
    int newCol = thiefCol;

    switch (direction) 
    {
    case 'w':
        if (thiefRow > 0) 
            newRow--; 
        break;

    case 'a':
        if (thiefCol > 0)
            newCol--; 
        break;

    case 's': 
        if (thiefRow < rows - 1) 
            newRow++; 
        break;

    case 'd': 
        if (thiefCol < cols - 1) 
            newCol++;
        break;

    default:
        cout << "Invalid command!" << endl; 
        return;

    }

    if (newRow == guardRow && newCol == guardCol) 
    {
        thiefRow = newRow;
        thiefCol = newCol;
    }
    else 
    {
        thiefRow = newRow;
        thiefCol = newCol;
    }
}

void Game::visit(int row, int col, Player& player) 
{
    if (row >= 0 && row < rows && col >= 0 && col < cols) 
    {
        world[row][col]->visit(player);
    }
}


int main() 
{
    Game game;
    game.playGame();
    return 0;
};
