#include "Player.h"

Player::Player() : name(""), age(0), score(0), x(0), y(0) {}

Player::Player(string n, int a, int s) : name(n), age(a), score(s), x(0), y(0) {}

Player::Player(int x, int y) : name(""), age(0), score(0), x(x), y(y) {}

void Player::SetName(string n) {
    name = n;
}

void Player::SetAge(int a) {
    age = a;
}

void Player::SetScore(int s) {
    score = s;
}

string Player::GetName() {
    return name;
}

int Player::GetAge() {
    return age;
}

int Player::GetScore() {
    return score;
}

void Player::PrintInfo() {
    cout << "Name: " << name << ", Age: " << age << ", Score: " << score << ", Position: (" << x << ", " << y << ")" << endl;
}

void Player::SetCoordinates(int x, int y) {
    this->x = x;
    this->y = y;
}
