#pragma once
#include "location.h"  
#include <iostream>
#include <vector>

using namespace std;

class Game
{
private:
    int rows, cols;
    location*** world;
    int thiefRow, thiefCol;
    int guardRow, guardCol;

public:
    Game();  
    ~Game(); 

    void cleanUp();
    void setUpGame(int rows, int cols, int thiefStartRow, int thiefStartCol, int guardStartRow, int guardStartCol);
    void drawGame();
    void playGame();
    void moveThief(char direction);
    void visit(int row, int col, Player& player);

};
